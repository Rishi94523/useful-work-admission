# Result ledgers for "The Price of Utility"

Code commit: 5e47933cc1d6f44330e693c8fd1cce56a6e8c20f

Each directory under results/ is the unmodified local output of one experiment,
with its execution manifest where the runner writes one. Earlier attempts and
misses are preserved rather than removed. SHA256SUMS lists every result file.
Repository: https://github.com/Rishi94523/useful-work-admission
Release bundles are excluded from code snapshots via export-ignore.

Scope: recorded results and analysis inputs, not a self-contained molecular rerun.
Full receptor/ligand libraries, native binaries, browser WASM/prepared assets,
and the complete raw molecular pool/trace corpus are not included. Re-running
molecular experiments requires the external inputs and build dependencies
specified by the benchmark protocols. Included fixture outputs are only a smoke test.

| Directory | Supports |
| --- | --- |
| `published-vina-validation-2026-09-15` | Stock Vina qualification of the five targets (Section 5.1, Supplementary S1) |
| `build-equivalence-2026-09-20` | Build-equivalence gates G1-G3 (Section 3.2) |
| `published-matched-2026-09-20-samebuild` | Matched decomposition campaign, 2,073 paired state jobs; comparison.json supplies the matched-compute table (Section 5.1) |
| `published-matched-2026-09-20` | Preserved earlier matched attempt stopped by the parity gate (not used for results) |
| `published-matched-2026-09-20-spacing0375` | Preserved earlier matched attempt stopped by the parity gate (not used for results) |
| `adversarial-2026-09-23` | Unit-level attacks, admission economics, integrity experiments, puzzle baseline, identity cost (Sections 5.3-5.5, Supplementary S4) |
| `driver-v2-2026-09-23` | Rescoring (v2) driver verification (Section 5.4) |
| `device-timing` | First phone timing study, four phones (Section 5.2, Supplementary S2) |
| `device-timing-subpuzzle` | Second phone timing study with the subpuzzle baseline, five phones (Section 5.2) |
| `priority-admission-2026-09-24` | Original single-seed effort-priority results, amendment 9 (Supplementary S3) |
| `priority-admission-2026-09-24-patience` | Original single-seed full-patience results, amendment 9b (Supplementary S3) |
| `attested-admission-2026-09-25` | Original single-seed attested-lane results, amendment 10 (Supplementary S3) |
| `admission-amendment12-2026-09-25` | Corrected five-seed availability replication, 1,120 runs, amendment 12 (Section 5.5, Supplementary S3) |
| `ticket-prototype-2026-09-24` | Isolated ticket prototype over loopback HTTP (Section 6, Supplementary S3) |
| `ticket-prototype-2026-09-24-wide` | Ticket prototype, wider configuration (Supplementary S3) |
| `ticket-molecular-2026-09-24` | Ticket prototype two-bundle native smoke check with real replay (Supplementary S3) |
| `hashcash-batches-2026-09-24` | Desktop subpuzzle hashcash variance baseline |
| `capacity-review-2026-09-24` | Capacity review of the ticket prototype |

Regenerate the paper figures and PDFs from the matching code snapshot:
place results/ at the repository root as local-research/, then run
`python scripts/make_paper_figures.py` and `python scripts/build_manuscript.py --pdf`.
Figure generation requires Python and matplotlib. PDF compilation additionally
requires LaTeX, latexmk/Perl and the Springer template files described in
docs/paper/README.md; these upstream template files are not bundled.
Original execution manifests record historical source hashes. Re-analysis
does not imply the current scripts match every historical execution manifest.

# Claude review and admission availability exploration — 24 September 2026

Reviewed through commit 42a657a. Historical molecular outputs, drivers, protocol
gates and Cloudflare deployments were not changed. This is a local working
report, excluded from Git. It distinguishes saved results, newly executed
fixtures, simulations and proposed designs.

## What Claude completed

- The 2,073-pair, three-seed, five-target matched campaign completed without
  execution failures. All five targets passed the declared AUC noninferiority
  gate; mean deltas are approximately -0.0008 to +0.0033. This establishes
  conditional ranking preservation on 96-compound panels, not universal docking
  accuracy. The five-target stock controls and failed earlier targets remain.
- Same-build reference, instrumented reference and driver controls separate
  implementation equivalence from cross-toolchain trajectory differences.
- Phase 1 contains 693 real unit-level attack trials. Pool-only commitments
  admit some truncated searches; trace binding detects the tested truncations.
  This is not a proof that every possible shortcut has been excluded.
- A native Hashcash timing baseline and scheduler-based economic experiments
  followed. Retry reseeding, hiding audit choices before uploads, and requiring
  three audited bundles before trust address measured attacks. The original
  economics experiment includes eight terminated configurations; do not report
  every configuration as completed. Attack strategies and hardware assumptions
  delimit any cost-parity claim.
- Scientific-integrity attacks found selection poisoning by client-reported
  energies. V2 rescores conformations before merge selection; all five control
  targets pass, and 33/33 honest corpus finalizations match v1 exactly. This is
  tested-corpus evidence, not exhaustive equivalence for arbitrary inputs.
- The compact commitment records pool plus SHA-256(trace); median corpus
  payload is about 19 KB rather than 163 KB. The device worker still uses full
  traces. SHA-256 collision resistance is an assumption, not mathematical byte
  equality or a proof of work by itself.
- V2 is a server finalization candidate. The full 2,073-pair campaign belongs
  to v1; keep this distinction in the paper and retain driver hashes.

## Cloudflare phone baseline: present, not missing

Re-read all five local reports under local-research/device-timing. Four sessions
with visibility instrumentation cover four phones. The earlier iPhone session
has hidden periods without overlap instrumentation and remains excluded from
the pooled timing comparison. Each retained session reports 17 exact unit hash
pairs, 16 warm timings and 48 puzzle solves. Four of the warm timings are
calibration, leaving 12 comparison rounds. All use only four distinct unit
indices from one molecular workload, repeatedly executed.

| Device | Warm unit median | Puzzle median | First unit callback since test start |
| --- | ---: | ---: | ---: |
| iPhone 15 | 2.041 s | 1.849 s | 3.366 s |
| Galaxy A57 | 2.020 s | 2.085 s | 7.282 s |
| Moto Edge 50 | 2.441 s | 1.863 s | 4.840 s |
| Galaxy M30s | 7.550 s | 5.864 s | 14.068 s |

These first-callback times are the saved at_ms fields, not inferred from adding
selected phases. Cold worker initialization does not prove an empty HTTP/cache
state; the iPhone assets_ms is only 91 ms in this session. These numbers do not
replace the earlier controlled cold-delivery experiments. Excluding calibration
gives unit medians 2.043, 2.020, 2.439 and 7.705 seconds respectively.

The phone comparison is real WASM Vina against a pure-JavaScript SHA-256 loop,
calibrated per device. That is a valid implementation comparison, not a claim
that all proof-of-work implementations are slower or more variable. The native
baseline uses Python's loop around native hashlib, also not an optimized C
mining loop. The timing worker generates challenges locally and uploads solve
counts/times without proof nonces. The collector checks reported unit hashes;
it does not remotely attest honest execution or independently verify puzzle
solutions. Appropriate for cooperative device measurement, not hostile-client
admission validation. No new phone run was performed during this review.

## New execution: real scheduler capacity counterexamples

Runner: scripts/explore_admission_capacity.py. Original pre-fix evidence is in
this directory; reproducible post-fix contrast is in sibling
capacity-review-2026-09-24-repro. Manifests are written before execution.

Tests use real SQLite scheduler transactions, separate pools for holders and
honest work, a simulated clock, fixture outputs and explicit replay verdicts.
They isolate occupancy by replenishing issuance tokens. They are not concurrent
HTTP throughput or molecular replay measurements. The separated adapter is
test-only, serial, and does not impose a production-safe submit-time queue cap.

| Scenario | Honest request |
| --- | --- |
| Current scheduler, 16 idle holders | blocked |
| Separate idle/submission counts, 16 idle holders | assigned and fixture credit redeemed |
| Separate counts, 256 idle holders | blocked at assignment cap |
| Current scheduler, 16 fabricated uploads awaiting replay | blocked |
| Separate counts, 16 fabricated uploads awaiting replay | blocked |

A second counterexample found a coding bug: rejected requests discarded the
fractional token refill. Starting with an empty bucket, 100 fresh-identity
requests over ten seconds yielded zero assignments despite rate=2/s. Preserving
fractional credit yielded 20. The regression failed before the one-line core
fix; all 72 research tests passed after it. This restores rate-limit behavior;
it does not give honest users a fair share of tokens under competing traffic.

## New execution: stronger puzzle baseline

Runner: scripts/benchmark_hashcash_batches.mjs. Evidence:
local-research/hashcash-batches-2026-09-24. Real Node/OpenSSL SHA-256 solves;
96 trials per configuration; rotated order; 65,536 expected total hashes each;
domain-separated subpuzzle indices, actual solution verification. The timed
verification loop includes assertions. No new device or network measurements.

| Subpuzzles | Median solve | p95 / median | Median verification |
| --- | ---: | ---: | ---: |
| 1 | 63.68 ms | 4.86 | 1.48 us |
| 16 | 89.02 ms | 1.47 | 19.77 us |
| 64 | 87.88 ms | 1.33 | 87.24 us |

Expected work is matched, not observed medians. The changing mean/median ratio
is expected when summing independent geometric variables. Separate seeded
100,000-sample geometric simulations predict p95/median of 4.30, 2.11, 1.48,
1.22 for 1, 4, 16, 64 subpuzzles; simulations are not measured wall times.

Conclusion: preserve the original phone result as a single-puzzle comparison.
Do not sell low latency variance as a unique advantage over proof of work.
Next device baseline should include optimized browser hashing and 16/64
subpuzzles, both equal-expected-work and equal-median comparisons. A 96-solve
microbenchmark is insufficient for a strong p99-tail claim.

## Recommended capacity direction, still a hypothesis

1. Do not reserve scarce replay-worker capacity while an untrusted browser is
   computing. Use authenticated, expiring work tickets and a bounded assignment
   ledger (or carefully designed unique seed allocation). No long-lived network
   connection or per-ticket heavyweight state is necessary. Authenticity alone
   does not establish work; tickets can still be collected or abused.
2. Preserve unique scientific assignment and atomic one-use redemption. If
   assignments become stateless, explicitly solve finite seed space, duplicate
   issuance, retry generations, consumed-credit storage and garbage collection.
   Simply signing a public seed does not solve those problems.
3. Apply independent limits to issuance, payload bytes, queued verification CPU
   and aggregation. A 4-unit bundle currently permits 64 MB of raw payload and
   stores hex JSON, potentially about 128 MB before additional copies. Normal
   19 KB payloads do not justify such loose Internet-facing bounds. Trusted
   verifier APIs must never be exposed as client-settable verdicts or audit draws.
4. For overload, evaluate a stateless, request-bound entry puzzle before scarce
   resource allocation. Bind purpose, policy, expiry, session and challenge;
   consume its acceptance atomically so one solution cannot reserve many seats.
   Keep established and newcomer service budgets separate, with bounded
   borrowing. IP limits are supplementary and must be tested for shared NATs.
5. A fixed tiny toll is insufficient. Holding 16 seats for 120 s requires only
   0.133 paid reservations/s; at 0.25 CPU-s per reservation that is 0.033 CPU
   equivalents under equal-speed assumptions. Removing idle occupancy matters
   more than charging a small price for it.
6. Fake submissions then become the main threat. Illustratively, two replay
   workers at 1.52 s/unit saturate at 1.32 failed audits/s. A 0.25 CPU-s entry
   toll costs about 0.33 attacker CPU equivalents to sustain that pressure,
   before hardware advantages. This is an analytical example, not deployment
   capacity measured here. Difficulty must track protected resource cost and
   load; useful-work fractions must include the toll and failed attempts.

At equal-speed reference costs, a 1.52 s toll added to four 1.52 s useful units
leaves 80% client computation useful; attached to one unit it leaves 50%.
This motivates overload-only treatment and reputation, not a universal toll.
No finite puzzle gives availability against an unbounded resource adversary.

## Scientific repair and paper priorities

The existing aggregate getter already blocks results associated with a
quarantined owner, but there is no complete recovery pipeline. Preserve bad
payloads as evidence, invalidate affected aggregate versions, distinguish
replayed-valid units from suspect unaudited ones, and issue fresh replacement
seeds into a new generation. Do not silently edit the frozen campaign or award
duplicate credits. Re-finalize with v2 and publish a new aggregate version.
Test late audit failure, restart, concurrent redemption and replacement racing
with a late original upload. Count all replacement/audit cost in useful yield.

Novelty needs comparison against client puzzles and volunteer-computing credit
and replication. These individual ingredients are established:
- https://www.ndss-symposium.org/ndss1999/cryptographic-defense-against-connection-depletion-attacks/
- https://www.ndss-symposium.org/wp-content/uploads/2017/09/Client-Puzzles-A-Cryptographic-Defense-Against-Connection-Depletion-Attacks.pdf
- https://github.com/BOINC/boinc/wiki/Validators
- https://boinc.berkeley.edu/boinc_a_platform_for_volunteer_computing.pdf

The candidate contribution is the experimentally established joint boundary:
scientific quality, shortcut-resistant sampled work accounting, poisoning-safe
aggregation, and bounded admission cost/availability. Attacker work per granted
admission and honest availability are different metrics: an attacker can gain
zero admissions while exhausting server replay capacity.

Next decisive experiment: a bounded real HTTP service with mixed honest arrivals,
idle holders, fake uploads, paid attackers and identity churn. Compare the
original policy, independent queue budgets, overload puzzle and reputation-only
baseline. Report honest completion and p95 delay, attacker CPU, verifier CPU,
peak memory, database/storage growth, bytes and repaired scientific yield.
Use explicit finite attack budgets and slow-device deadlines. Neither a
simulated clock nor these occupancy fixtures establish production resilience.

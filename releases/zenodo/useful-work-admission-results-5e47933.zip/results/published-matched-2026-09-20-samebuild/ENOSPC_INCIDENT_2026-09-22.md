# Disk-exhaustion incident, 22 September 2026

The campaign aborted at job 721 with `OSError: [Errno 28] No space left on
device`. The F: volume filled because each job folder retains about 32 MB of
intermediate task and trace files; 2,073 jobs require roughly 66 GB on a 74 GB
volume that was already largely full. The run could not have completed as
configured.

## Ledger change

Thirteen rows were removed so their jobs re-run: eleven recorded
`[Errno 28] No space left on device` directly and two recorded `Worker stopped`,
which is the same failure observed one level down, where the worker process
died unable to write its task files. All five targets were affected.

Removal was necessary because the runner's skip-set is built from every ledger
row without consulting `ok`, so a failed row is never retried, and `analyze()`
drops any compound with a failed state. Left in place, these thirteen rows would
have made all five target panels incomplete and the campaign would have produced
no noninferiority result.

These are infrastructure failures, not scientific outcomes, so removing them is
not selection on results. The unmodified ledger is preserved verbatim as
`matched.jsonl.enospc-crash-2026-09-22`.

## Storage change

Intermediate `normal/` and `medium/` task directories were deleted for jobs
already recorded complete. Scores, evaluation counts, timings and pose hashes
remain in the ledger, and the referenced pose files remain on disk and still
verify against their recorded SHA-256. Raw per-task traces for those campaign
jobs are not recoverable; replay and audit evidence rests on the parity gate and
the earlier whole-run audit work, which are unaffected.

A janitor process removes these directories for completed jobs while the
campaign runs. The runner itself was not modified, because its hash is bound
into the frozen execution manifest and any edit would refuse resumption.

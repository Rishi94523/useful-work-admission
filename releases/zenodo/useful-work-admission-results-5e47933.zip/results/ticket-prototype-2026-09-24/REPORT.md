# Integrated four-part admission experiment — 24 September 2026

All four proposed mechanisms are implemented together in the isolated
research/ticket_admission.py prototype. Existing molecular code, campaigns,
PoolAdmission and Cloudflare deployments are unchanged.

## Implementation

1. HMAC tickets bind owner/session, immutable scientific configuration hash,
   fresh server-assigned seed range, expiry and policy tier. Issuance persists
   counters and rate buckets, not a database row or audit seat per ticket.
2. Tickets do not reserve verifier capacity. Newcomer and established lanes
   each reserve eight queue entries and half the configured byte budget.
3. Body and per-unit byte limits, seed membership, output commitment, session
   binding, total queued bytes and queue length are enforced. Audit selection
   occurs after full commitment and is not disclosed to clients. A trusted
   replay verdict must match the durable output digest. Scientific persistence
   and granting a one-use credit are transactional. Duplicate submissions and
   redemption races are rejected; expired tickets cannot reuse pruned receipts.
4. Overload triggers a stateless SHA-256 entry puzzle for newcomers, bound to
   ticket, owner, output commitment, difficulty, purpose and expiry. A proof is
   needed before entering the expensive queue. Fixed difficulty per experiment;
   automatic adaptive pricing is not implemented.

## What ran and what was modeled

scripts/benchmark_ticket_admission.py sends actual loopback HTTP requests into
the prototype. HMAC, real SHA-256 solves, proof verification, payload checks,
SQLite state, queue caps and one-use redemption execute normally.

Arrival times and molecular replay-service time are simulated. Two replay
lanes each take 1.52 modeled seconds per job; 250 ms scheduling steps produce
1.75 s unloaded queue-to-credit latency. Scientific verdicts are explicit
fixtures. HTTP requests are serially driven. This is not production throughput
or a concurrent HTTP load result. Queue delay excludes molecular client work,
puzzle time and network time. Arrivals do not enforce a client CPU budget or
wait for real-time proof solving. The test session header is an authenticated
fixture convention, NOT safe production authentication. Both tiers replay one
unit per submitted job; deferred low-risk auditing is not evaluated here.

Each 120-s case has 60 honest newcomers and 60 established users. Attack cases
add 480 fresh identities at four requests/s, attacker first on coincident
arrivals. There are no client retries. Denied users remain in the denominator.

## Initial integrated cases

The original two-ticket/s issuance cap itself starves newcomers: idle traffic
leaves 7/60 newcomer completions even though it reserves zero replay slots.
Established users complete 60/60. The 10-bit puzzle in these initial cases is
instrumentation only. Original manifests and outputs remain in this directory.

## Wider issuance and a real 16-bit entry puzzle

Follow-up evidence: ../ticket-prototype-2026-09-24-wide. Issuance is 64 tickets/s
per tier, isolating queue behavior from the low issuance cap; attacks above
that limit are not evaluated. All four scenarios rerun with the same workload.

| Traffic | Honest newcomers | Established | Fake outputs replayed/rejected |
| --- | ---: | ---: | ---: |
| None | 60/60 | 60/60 | 0 |
| Idle ticket holders | 60/60 | 60/60 | 0 |
| Fabrication without puzzle solving | 60/60 | 60/60 | 14 |
| Fabrication with real puzzle solving | 1/60 | 60/60 | 75 |

Idle cases have 1.75 s p95 queue-to-credit delay in both lanes. Unpaid fabrication
raises newcomer p95 to 12 s, while established users remain at 1.75 s. These
delays are conditional on success and are not full user-visible latency.

The unpaid case rejects 466 submissions at the puzzle gate; 14 enter replay
during initial/rising load. An overload-only gate does not charge every fake
submission. The paid case solves 474 attacker and 59 honest newcomer puzzles:
36,330,396 actual hashes and 45.62 s combined solve wall time. Do not attribute
the combined work exclusively to attackers. 405 attacker and 59 honest
newcomer submissions receive queue_full. No fabricated output receives credit.
Queues stay bounded (maximum nine observed rows), but that is not newcomer
fairness. The gate is too cheap for this submitted rate and replay expense.
This is a failure of the tested parameterized policy, not a proof that every
dynamic gate/fairness policy must fail.

## Actual molecular integration

scripts/smoke_ticket_molecular.py uses the pinned v2 executable, frozen WEE1
inputs and new private directories. It computes four independently seeded
256k units, submits pools plus trace hashes, actually replays the selected unit,
and binds the result to the scientific-store transaction and credit redemption.

| Bundle | Four searches | Selected replay | Bytes | Result |
| --- | ---: | ---: | ---: | --- |
| Honest | 5.738 s | 1.418 s | 80,913 | exact replay; stored; credit redeemed |
| All trace commitments corrupted | 5.679 s | 1.384 s | 80,941 | rejected; no credit |

Evidence: ../ticket-molecular-2026-09-24/results.json. This is a two-bundle native
integration smoke test, not ranking validation or browser throughput. Costs
exclude driver initialization. Corrupting every unit guarantees the one-unit
sample encounters corruption; this is not a partial-cheating detection study.

## Verification and limits

All 82 research tests pass, including ten new tests for unique work allocation,
MAC/session/expiry checks, input/commitment substitution, real puzzle acceptance,
wrong-ticket/expired/altered proofs, byte caps and reservations, concurrent
duplicates, one-use credits, durable counters, expiry and storage rollback.

There is no production HTTP authentication, reputation-acquisition service,
atomic multi-worker replay claim/recovery, distributed counter replication,
campaign rollover, scientific repair or adaptive price controller. pending()
requires the trusted one-worker-per-lane discipline used by the harness. Valid
scientific data storage needs a separate long-term quota. Finite seed allocation
and issuance flooding remain resource limits, even without per-ticket rows.

## Decision

The complete design handles the tested idle-holder attack and protects
established service. It also rejects most unpaid fabricated submissions cheaply.
It does NOT yet preserve newcomer service against paid floods. Availability
remains a design/pricing problem, not merely missing evidence scale.

Next: predeclare finite attacker CPU budgets; calibrate an optimized puzzle
solver against protected replay cost; require solve completion before modeled
arrival; compare bounded fair queuing and adaptive overload pricing. Measure
slow-phone burden and wasted honest solves. Keep long work-ticket lifetimes
separate from short scarce-queue reservations. Do not claim availability against
an unbounded paid adversary. No existing service was deployed or changed.
